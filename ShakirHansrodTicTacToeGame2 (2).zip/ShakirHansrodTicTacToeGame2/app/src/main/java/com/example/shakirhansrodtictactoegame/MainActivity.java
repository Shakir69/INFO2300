package com.example.shakirhansrodtictactoegame;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView gameStatus ,tv_playerX,tv_playerX_score,tv_playerO,tv_playerO_score;
    private Button[] buttons = new Button[9];
    private int playerXScoreCount, playerOScoreCount, roundCount;
    boolean gamePlayer;
    int [] gameState = {2,2,2,2,2,2,2,2,2};
    private Button newGame;
    int [][] winningCombonations = {
            {0,1,2}, {3,4,5}, {6,7,8},{0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_playerX_score = (TextView) findViewById(R.id.tv_playerX_score);
        tv_playerO_score = (TextView) findViewById(R.id.tv_playerO_Score);
        gameStatus = (TextView) findViewById(R.id.gameStatus);
        newGame = (Button) findViewById(R.id.newGame);

        for (int i=0; i < buttons.length; i++){
            String buttonID = "btn_" + i;
            int resourceID = getResources().getIdentifier(buttonID,  "id", getPackageName());
            buttons[i] = (Button) findViewById(resourceID);
            buttons[i].setOnClickListener(this);
            roundCount = 0;
            playerXScoreCount = 0;
            playerOScoreCount = 0;
            gamePlayer = true;
        }

    }

    @Override
    public void onClick(View v) {
        if(!((Button)v).getText().toString().equals("")){
            return;
        }
        String buttonID = v.getResources().getResourceEntryName(v.getId());
        int gameStatePointer = Integer.parseInt(buttonID.substring(buttonID.length()-1,buttonID.length()));

        if(gamePlayer){
            ((Button) v).setText("X");
            ((Button) v).setTextColor(Color.parseColor("#1cf4ff"));
            gameState[gameStatePointer] = 0;
        }else{
            ((Button) v).setText("O");
            ((Button) v).setTextColor(Color.parseColor("#fdff2f"));
            gameState[gameStatePointer] = 1;
        }
        roundCount++;

        if(checkingWinner()) {
            if(gamePlayer) {
                playerXScoreCount++;
                updatePlayerScore();
                Toast.makeText(this, "PLAYER X HAS WON!!", Toast.LENGTH_SHORT).show();
                playNewGame();
            } else {
                playerOScoreCount++;
                updatePlayerScore();
                Toast.makeText(this, "PLAYER 0 HAS WON!!", Toast.LENGTH_SHORT).show();
                playNewGame();
            }
        }else if(roundCount == 9){
            playNewGame();
            Toast.makeText(this, "DRAW!!!", Toast.LENGTH_SHORT).show();
        }else{
            gamePlayer = !gamePlayer;
        }

        if(playerXScoreCount > playerOScoreCount){
            gameStatus.setText("Player X IS WINNING!");
        }else if(playerOScoreCount > playerXScoreCount){
            gameStatus.setText("Player O IS WINNING!");
        }else{
            gameStatus.setText("");
        }

        newGame.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                playNewGame();;
                playerXScoreCount = 0;
                playerOScoreCount = 0;
                gameStatus.setText("");
                updatePlayerScore();
            }
        });

    }
    public boolean checkingWinner(){
        boolean winnerResult = false;

        for(int [] winningPosition: winningCombonations){
            if(gameState[winningPosition[0]]== gameState[winningPosition[1]] &&
                    gameState[winningPosition[1]]== gameState[winningPosition[2]] &&
                    gameState[winningPosition[0]] !=2){
                winnerResult = true;
            }
        }
        return winnerResult;
    }
    public void updatePlayerScore(){
        tv_playerX_score.setText(Integer.toString(playerXScoreCount));
        tv_playerO_score.setText(Integer.toString(playerOScoreCount));
    }

    public void playNewGame(){
        roundCount = 0;
        gamePlayer = true;

        for(int i = 0; i < buttons.length; i++){
            gameState[i] = 2;
            buttons[i].setText("");
        }
    }
}