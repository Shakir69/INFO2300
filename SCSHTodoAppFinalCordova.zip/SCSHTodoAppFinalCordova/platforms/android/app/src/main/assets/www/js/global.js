function initDB(){
    try{

        DB.createDatabase();
        if (db) {
            console.info("Creating Tables ...");
            DB.createTables();
            DB.populateTables();
        }
        else{
            console.error("Error: Cannot create tables: Database does not exists");
        }
    }catch(e){
        console.error("Error (Fatal): Error in initDB. Can not proceed");
    }
}

function GetSelector(x) {

    //Sets the type ID to local storage under name typeId
    localStorage.setItem("typeId", x );


    //todo call the get todo function
    $(location).prop('href', '#pageModifyTodo');
    showCurrentTodo();

}
function updateBtn_click(){
   if( doValidate_frmPageModifyTodo()){

       //get values of off index and set the values to variables
       var name = document.getElementById("name").value;
       var desc = document.getElementById("description").value;
       var typeId = document.getElementById("_type").value;
       var date = document.getElementById("Date").value;
       var id = localStorage.getItem("typeId" );

       //parse the data that is of a different data type
       var y = Date.parse(date);
       var  x = parseInt(typeId);
       var options = [ name, desc, date,x,id];
       function callback(){
           alert("Feedback modded");
       }
       Todo.update(options, callback)
   }
}

function saveBtn_click()
{
    if(doValidate_frmPageAdd()){
       var name = document.getElementById("taskName").value;
       var desc = document.getElementById("taskDescription").value;
       var typeId = document.getElementById("type").value;
       var date = document.getElementById("doByDate").value;


       var y = Date.parse(date);
       var  x = parseInt(typeId);

        var options = [name, desc, date, x];

        function callback() {

            alert("New todo added");
        }

        Todo.insert(options, callback())
    }
}

function init() {


    $("#updateBtn").on("click", updateBtn_click);
    $("#btnDelete").on("click", deleteFeedback);
    $('#pageAdd').on("pageshow", pageAddTodoShow);
    $("#saveBtn").on("click", saveBtn_click);
    $("#pageShowAllTodo").on("pageshow", GetAllTodo);
    $("#pageModifyTodo").on("pageshow", showCurrentTodo);

}



//This populates the drop down menu for the type
function successTransaction(_, { rows }) {

    for (const row of rows)
    {
        optionText = row.name;
        optionValue = row.id; // i;
        $('#type').append($('<option>').val(optionValue).text(optionText));

    }
}

function _successTransaction(_, { rows }) {

    for (const row of rows)
    {
        optionText = row.name;
        optionValue = row.id; // i;
        $('#_type').append($('<option>').val(optionValue).text(optionText));

    }
}
//This functions is brought to you by https://stackoverflow.com/questions/3364493/how-do-i-clear-all-options-in-a-dropdown-box#:~:text=To%20remove%20the%20options%20of,0%3B%20i%2D%2D)%20%7B%20selectElement.
function removeOptions() {
    var selectElement = document.getElementById("type");
    var i;
     var L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
        selectElement.remove(i);
    }
}
function _removeOptions() {
    var selectElement = document.getElementById("_type");
    var i;
    var L = selectElement.options.length - 1;
    for(i = L; i >= 0; i--) {
        selectElement.remove(i);
    }
}


function pageAddTodoShow(){
    removeOptions();
        document.getElementById("taskName").value = "";
        document.getElementById("taskDescription").value = "";
        document.getElementById("doByDate").value = null;
    Type.selectAll(null, successTransaction);

}



//make sure to add code above this line
$(document).ready(function () {


    init();
    initDB();
});
