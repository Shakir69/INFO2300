function doValidate_frmPageAdd(){
    var form = $("#add_todo");
    form.validate({
        rules:{
            taskName:{
                required: true,
                minlength: 2,
                maxlength: 30
            },
            taskDescription:{
                minlength: 2,
                required: true,
                maxlength: 100
            },
            doByDate:{
                required: true,
            },


        },
        messages:{
            taskName:{
                required: "You must enter a Task name",
                minlength: "The Task Name must be between 2 to 30 characters long"
            },
            taskDescription:{
                required: 'Task Description is required',
            },
            doByDate:{
                required: "Do by Date is required"
            },
        }
    });
    return form.valid();
}
function doValidate_frmPageModifyTodo(){
    var form = $("#my_todo");
    form.validate({
        rules:{
            name:{
                required: true,
                minlength: 2,
                maxlength: 30
            },
            description:{
                minlength: 2,
                required: true,
                maxlength: 100
            },
            Date:{
                required: true,
            },


        },
        messages:{
            name:{
                required: "You must enter a Task name",
                minlength: "The Task Name must be between 2 to 30 characters long"
            },
            description:{
                required: 'Task Description is required',
            },
            Date:{
                required: "Do by Date is required"
            },
        }
    });
    return form.valid();
}





