
const Type ={
    selectAll: function (arguments, callback) {


        function txFunction(tx) {
            const sql1 = "SELECT * FROM type;";

            tx.executeSql(sql1, [], callback, errorHandler);

        }

        function finished()
        {
            console.log("Retrived");
        }

        db.transaction(txFunction, errorHandler, finished);
    }, select: function (options, callback) {
        function txFunction(tx) {
            const sql = "SELECT * from type WHERE id=?;";
            tx.executeSql(sql, options, callback, errorHandler);
        }

        function successTransaction() {
            console.info("Success: Select transaction successfully");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
};

var Todo = {

    insert: function (options, callback) {
        function txFunction(tx) {
            const sql = "INSERT INTO todo(TaskName, TaskDescription , doBy, TypeId) VALUES(?,?,?,?);";
            tx.executeSql(sql, options, callback, errorHandler1);
        }

        function successTransaction1() {
            console.info("Success: Insert todo successfully");

        }
        function errorHandler1(tx, error) {
            console.error("SQL error: " + error.message);
        }

        db.transaction(txFunction, errorHandler1, successTransaction1);
    },
    update: function(options, callback){
        function txFunction(tx) {
            const sql  = "UPDATE todo SET TaskName=?, TaskDescription=?, DoBy=? , TypeId=? WHERE id=?;";
            tx.executeSql(sql, options, callback, errorHandler2 );
        }
        function successTransaction() {
            console.info("Success: Update todo successfully");
        }
        function errorHandler2(tx, error) {
            console.error("SQL error: " + error.message);
        }
        db.transaction(txFunction, errorHandler2, successTransaction);
    },
    select: function (options, callback) {
        function txFunction(tx) {
            const sql = "SELECT * from todo WHERE id=?;";
            tx.executeSql(sql, options, callback, errorHandler);
        }

        function successTransaction() {
            console.info("Success: Select todo successfully");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    selectAll: function (options, callback) {
        function txFunction(tx) {
            const sql = "SELECT td.* , ty.name as typeName FROM todo as td  join type as ty on ty.id = td.typeId;";
            tx.executeSql(sql, options, callback, errorHandler);
        }

        function errorHandler1(tx,error) {
            console.error("SQL error: " + error.message);
        }
        function successTransaction2() {
            console.info("Success: SelectAll transaction successfully");
        }
        db.transaction(txFunction, errorHandler1, successTransaction2);

    },

    delete: function(options, callback){
        function txFunction(tx) {
            const sql  = "DELETE FROM todo where id=?;";
            tx.executeSql(sql, options, callback, errorHandler3 );
        }
        function successTransaction() {
            console.info("Success: Delete transaction successfully");
        }
        function errorHandler3(tx, error) {
            console.error("SQL error: " + error.message);
        }
        db.transaction(txFunction, errorHandler3, successTransaction);
    },

};