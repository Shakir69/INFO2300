

var db;

function errorHandler(error) {
    console.error("SQL error: " + error.message);
}

var DB = {
    createDatabase: function () {
        var shortName = "scshdb";
        var version = "1.0";
        var displayName = "DB final";
        var dbSize = 2 * 1024 * 1024;

        function dbCreateSuccess() {
            console.info("Success: Database create successfully");
        }

        db = openDatabase(shortName, version, displayName, dbSize, dbCreateSuccess);
    },

    populateTables: function() {
        function txFunction(tx){

            var options = [];
            function successCallback() {

              //  console.info("Success: drop table: type successful.");
            }


            //pre seed all the type data

            tx.executeSql("INSERT INTO type (name) VALUES ('shoping');", options, successCallback, errorHandler);
            tx.executeSql("INSERT INTO type (name) VALUES ('homework');", options, successCallback, errorHandler);
            tx.executeSql("INSERT INTO type (name) VALUES ('work');", options, successCallback, errorHandler);
            tx.executeSql("INSERT INTO type (name) VALUES ('cleaning');", options, successCallback, errorHandler);



        }

        function successTransaction() {
            console.info("Success: inserted data successful");
        }

        function insertErrorHandler(error) {
            console.error("SQL INSERT error: " + error.message);
        }

        db.transaction(txFunction, insertErrorHandler, successTransaction);




    },

    createTables: function () {
        function txFunction(tx) {
            var sqlDrop1 = "DROP TABLE IF EXISTS todo;";
            var sqlDrop = "DROP TABLE IF EXISTS type;";
            var sql = " CREATE TABLE IF NOT EXISTS type( "
                + "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
                + "name VARCHAR(20) NOT NULL);";

            var options = [];

            function successCallback() {

                console.info("Success: Create table: type successful.");

            }
            tx.executeSql(sqlDrop1, options, successCallback, errorHandler);
            tx.executeSql(sqlDrop, options, successCallback, errorHandler);
            tx.executeSql(sql, options, successCallback, errorHandler);
        }


        function successTransaction() {

            console.info("Success: Create tables type successful");
        }
        db.transaction(txFunction, errorHandler, successTransaction);

        db.transaction(function (tx) {
          //Creates the tabel in the data base if none exist , add colloumns and fields that we need
            var sql = "CREATE TABLE IF NOT EXISTS todo( " +
                "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "taskName VARCHAR(30) NOT NULL," +
                "typeId INTEGER NOT NULL," +
                    "taskDescription VARCHAR(30)," +
               "doBy DATE," +
                "FOREIGN KEY(typeId) REFERENCES type(id));";

            var options = [];

            tx.executeSql(sql, options, function () {
                console.info("Sql command execution successful");
            }, function (error) {
                console.error("Error in executing sql");
            });
        }, function (error) {
            console.error("Error in todo");
        }, function () {
            console.info("Success: Create tables todo successful");
        });
    },
    dropTables: function () {

        function txFunction(tx) {
            var sql = "DROP TABLE IF EXISTS type;";
            var sql1 = "DROP TABLE IF EXISTS todo;";
            var options = [];
            function successCallback() {
                console.info("Success: drop table: type successful.");
            }
            tx.executeSql(sql, options, successCallback, errorHandler);
            tx.executeSql(sql1, options, successCallback, errorHandler);
        }
        function successTransaction() {
            console.info("Success: drop tables todo successful");
        }
        db.transaction(txFunction, errorHandler, successTransaction);
    }
};
