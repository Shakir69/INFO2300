function testingValidation() {
    if (doValidate_frmPageAdd()) {
        console.log("The Form is valid");
    } else {
        console.log("The Form is invalid");
    }
}

//deletes all thefee
function deleteFeedback() {
    var id = localStorage.getItem("typeId");

    var options = [id];

    function callback() {
        console.info("Success: todo deleted successfully");
        alert("todo deleted successfully");

        $(location).prop('href', "#pageShowAllTodo");
    }

    Todo.delete(options, callback);
}

function exportList() {

    var options = [];

    function callbackExport(tx, {rows}) {


    }

    Todo.selectAll(options, callbackExport);
}

//shows the review selected by the user , will auto populate the fields on the mod fedback page

function showCurrentTodo() {
    var id = localStorage.getItem("typeId");

    console.log("In Show Current");

    var options = [id];

    function callback(tx, results) {

        var row = results.rows[0];
        var tn = row.taskName;
        var td = row.taskDescription;
        var ty = row._type;
        var dt = row.doBy;
        $("#name").val(tn);
        $("#description").val(td);
       $("#_type").val(ty);
        $("#Date").val(dt);


    }
    _removeOptions();
    Type.selectAll(null  ,_successTransaction);
    Todo.select(options, callback);
}

//lists all of the todos in a list element
function GetAllTodo() {
    var options = [];


    function callbackShow(tx, {rows}) {

        i = 0;

        var htmlCode = "";

        for (const row of rows) {
            var abc = row.taskName;

            console.log("    ---> " + abc + "--> " + row.typeId + " --> " + row.taskDescription + " --> " + row.doBy);
            htmlCode += `
            <li>
            <a onclick="GetSelector(${row['id']}); showCurrentTodo()" data-row-id=${row['id']} data-theme="a" value="${row['id']}" >
            <h3>Task Name : ${row.taskName}</h3>
            <p>Task Description : ${row.taskDescription} </p>
            <p>Do By : ${row.doBy}</p>
            <p>type : ${row.typeName}</p>
            </a>
            </li>
              `;

            $("#lvAll a").on("click", GetSelector);

            i++;
        }
        var lv = $("#lvAll");

        lv = lv.html(htmlCode);
        lv.listview("refresh");


    }


    Todo.selectAll(options, callbackShow);


}

function getToDoAsArray(){
    var options = [];

    var resultArray = [];
    function callbackSetToLocal(tx, {rows} ) {
        localStorage.setItem("todoArray", null);
        for (const row of rows) {

            var combo = row.taskName + " " + row.taskDescription + " "  + row.doBy.toString() + " " + row.typeName + "|";
            resultArray.push(combo);
            localStorage.setItem("todoArray", resultArray);

        }
    }
    Todo.selectAll(options, callbackSetToLocal);
}

function Download () {
    getToDoAsArray();
    let filename = document.getElementById("txtFileName").value + ".txt";
    let text = localStorage.getItem("todoArray");
    alert("" + text);
    if(filename == null || filename == ""){
        filename = "NewTodoList";
    }
    let blob = new Blob([text], {type:'text/plain'});
    let link = document.createElement("a");
    link.download = filename;
    //link.innerHTML = "Download File";
    link.href = window.URL.createObjectURL(blob);
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(link.href);
    }, 100);
}